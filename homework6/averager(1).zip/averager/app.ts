import {Averager} from "./src/Averager";

new Averager();

