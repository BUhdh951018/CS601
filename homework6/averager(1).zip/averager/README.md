# Averager

This readme file needs love.  I haven't the time to fill it in.
